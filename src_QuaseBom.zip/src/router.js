import Vue from 'vue'
import Router from 'vue-router'

import GridAgenda from '@/components/GridAgenda'
import CadastroCliente from '@/components/CadastroCliente'
import CadastroAgenda from '@/components/CadastroAgenda'


Vue.use(Router)

export default new Router({
    mode: 'history',
    base: process.env.BASE_URL,
    routes: [{
            path: '/',
            name: 'agenda',
            component: GridAgenda
        },
        {
            path: '/cadastro/cliente',
            name: 'CadastroCliente',
            component: CadastroCliente,
        },
        {
            path: '/agenda/cadastro',
            name: 'cadastroagenda',
            component: CadastroAgenda,
        }
    ]
});