<template>
  <v-flex xs12>
    <v-card light color="blue light">
      <v-card-text class="white--text px-1">{{titulo}}</v-card-text>
    </v-card>
  </v-flex>
</template>

<script>
export default {
  props: ['titulo'],  
  // data: () => {   
      
  // },
  
};
</script>

