<template>
  <v-app id="inspire">
      <!-- <menu-lateral  :fechado="false" /> -->
    
    <v-navigation-drawer
      v-model="drawer"
      :mini-variant.sync="mini"
      :clipped="$vuetify.breakpoint.lgAndUp"
      fixed
      app
    >
      <v-list>
        <v-list-tile>
          <v-list-tile-action>
            
              <router-link to='/'><v-icon>schedule</v-icon></router-link>
              
            
          </v-list-tile-action>
          <v-list-tile-title>Agenda</v-list-tile-title>
        </v-list-tile>

        <v-list-group prepend-icon="account_circle" value="true">
          <template v-slot:activator>
            <v-list-tile>
              <v-list-tile-title>Cadastro</v-list-tile-title>
            </v-list-tile>
          </template>

          <v-list-group no-action sub-group value="true">
            <template v-slot:activator>
              <v-list-tile>
                <v-list-tile-title>Pessoa</v-list-tile-title>
              </v-list-tile>
            </template>

            <v-list-tile v-for="(cadastro, i) in cadastros" :key="i">
              
             <v-list-tile-title v-text="cadastro[0]"></v-list-tile-title>
              <v-list-tile-action>
               <v-icon v-text="cadastro[1]" ></v-icon>
              </v-list-tile-action>
              
            </v-list-tile>
          
          </v-list-group>

          <v-list-group no-action sub-group value="true">
            <template v-slot:activator>
              <v-list-tile>
                <v-list-tile-title>Pagamento</v-list-tile-title>
              </v-list-tile>
            </template>

            <v-list-tile v-for="(pagamento, i) in pagamentos" :key="i" >
              <v-list-tile-title v-text="pagamento[0]"></v-list-tile-title>
              <v-list-tile-action>
                <v-icon v-text="pagamento[1]"></v-icon>
              </v-list-tile-action>
            </v-list-tile>
          </v-list-group>
        </v-list-group>
      </v-list>
    </v-navigation-drawer>

    <!-- menu superior -->

    <v-toolbar :clipped-left="$vuetify.breakpoint.lgAndUp" color="blue darken-3" dark app fixed>
      <v-toolbar-side-icon @click.stop.prevent="mini = !mini"></v-toolbar-side-icon>
      <v-toolbar-title>Schedule</v-toolbar-title>
      <v-spacer></v-spacer>
      <v-toolbar-items class="hidden-sm-and-down">
        <v-btn flat>Novo</v-btn>
        <v-btn flat>Pesquisar</v-btn>
      </v-toolbar-items>
    </v-toolbar>

     <!-- Veiw Principal -->
    <v-content>
      <v-container fluid fill-height>
        <v-layout>
          <v-flex>
            <router-view/>
          </v-flex>
        </v-layout>
      </v-container>
    </v-content>


  </v-app>
</template>

<script>

//import MenuLateral from '@/components/MenuLateral'

export default {
  data: () => ({
    dialog: false,
    drawer: true,
    mini: true,
    cadastros: [
            [ "Cliente", "people_outline" ], 
            [ "Usuário", "people" ]
        ],
    pagamentos: [["Forma", "money"], ["Prazo", "money"]],

    // items: [
    //   { icon: "contacts", text: "Contacts" },
    //   { icon: "history", text: "Frequently contacted" },
    //   { icon: "content_copy", text: "Duplicates" },
    //   {
    //     icon: "keyboard_arrow_up",
    //     "icon-alt": "keyboard_arrow_down",
    //     text: "Labels",
    //     model: true,
    //     children: [{ icon: "add", text: "Create label" }]
    //   },
    //   {
    //     icon: "keyboard_arrow_up",
    //     "icon-alt": "keyboard_arrow_down",
    //     text: "More",
    //     model: false,
    //     children: [
    //       { text: "Import" },
    //       { text: "Export" },
    //       { text: "Print" },
    //       { text: "Undo changes" },
    //       { text: "Other contacts" }
    //     ]
    //   },
    //   { icon: "settings", text: "Settings" },
    //   { icon: "chat_bubble", text: "Send feedback" },
    //   { icon: "help", text: "Help" },
    //   { icon: "phonelink", text: "App downloads" },
    //   { icon: "keyboard", text: "Go to the old version" }
    // ]
  }),
  props: {
    source: String
  },
  components: {
      //'menu-lateral' : MenuLateral
  }
  // methods: {
  //   //mudarpara(campo) {
  //    // console.log('passei aqui: ' + campo)
      
      
  //     //console.log(window.location.pathname)
      
  //     //window.location.href = (window.location.pathname+ "cadastro/cliente")
  //   }
  
};
</script>


<style type="text/css"> 
a:link 
{ 
  text-decoration:none; 
  
} 
</style>