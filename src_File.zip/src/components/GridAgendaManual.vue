<template>
 
  <table class="table" >
    <thead>
      <tr>
        <td width="100px">Horários_</td>
        <td>Fulano</td>
        <td>Ciclano</td>
      </tr>
    </thead>
      <tbody>
        <tr>
          <td>10:00</td>        
          <td :click="agendar">VAGO</td>
          <td>VAGO</td>
        </tr>
        <tr>
          <td>10:30</td>        
          <td>Wallzin</td>
          <td>VAGO</td>
        </tr>
        <tr>
          <td>11:00</td>        
          <td>VAGO</td>
          <td>Wallzin</td>
        </tr>
      </tbody>
    
  </table>



  <!-- <v-data-table
    :headers="headers"
    :items="desserts"
    class="elevation-1"
  >
    <template v-slot:items="props">
      <td>{{ props.item.name }}</td>
      <td class="text-xs-right">{{ props.item.calories }}</td>
      <td class="text-xs-right">{{ props.item.fat }}</td>
      <td class="text-xs-right">{{ props.item.carbs }}</td>
      <td class="text-xs-right">{{ props.item.protein }}</td>
      <td class="text-xs-right">{{ props.item.iron }}</td>
    </template>
  </v-data-table> -->
</template>

<script>
  export default {
    data () {
        return {
        }
    },
    methods: {
        agendar: function(){
            alert('Agendado meu querido!')
        }
    }
  }

</script>


<style>
.table {
  width: 100%
}
</style>
