import Vue from 'vue'
import Router from 'vue-router'

import GridAgenda from '@/components/GridAgenda'
import CadastroCliente from '@/components/CadastroCliente'


Vue.use(Router)

export default new Router({
    mode: 'history',
    base: process.env.BASE_URL,
    routes: [{
            path: '/',
            name: 'agenda',
            component: GridAgenda
        },
        {
            path: '/cadastro/cliente',
            name: 'CadastroCliente',
            component: CadastroCliente,

        }
    ]
})