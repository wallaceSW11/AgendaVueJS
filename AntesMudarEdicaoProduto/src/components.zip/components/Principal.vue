<template>
<v-app id="inspire">
    
    <v-toolbar color="indigo" dark fixed app>
      <v-toolbar-side-icon @click.stop="drawer = !drawer"></v-toolbar-side-icon>
      <v-toolbar-title>Barbershop</v-toolbar-title>
    </v-toolbar>

  
    <v-navigation-drawer
      v-model="drawer"
      fixed
      app
    >
      <v-list dense>
        <v-list-tile >
          <v-list-tile-action>
            <v-icon>home</v-icon>
          </v-list-tile-action>
          <v-list-tile-content>
            <router-link to="/">Agenda</router-link>             
          </v-list-tile-content>
        </v-list-tile>
        <v-list-tile>
          <v-list-tile-action>
            <v-icon>contact_mail</v-icon>            
          </v-list-tile-action>
          <v-list-tile-content>
              <router-link to="/cadastro/cliente">Cadastro Cliente</router-link>            
          </v-list-tile-content>
        </v-list-tile>
      </v-list>
    </v-navigation-drawer>





    <v-content>
      <v-container fluid fill-height>
        <v-layout>
          <v-flex >
              <router-view />           
          </v-flex>
        </v-layout>
      </v-container>
    </v-content>
    
    <v-footer color="indigo" app>
      <span class="white--text">&copy; 2019</span>
    </v-footer>
  </v-app>
</template>

<script>
  export default {
    data: () => ({
      drawer: false
    }),
    props: {
      source: String
    }
  }
</script>