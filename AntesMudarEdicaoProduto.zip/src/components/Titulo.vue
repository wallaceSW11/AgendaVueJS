<template>
<div>
<span class="title">{{titulo}}</span>
          <v-divider></v-divider>
</div>
    
</template>

<script>
export default {
    props: ['titulo']
}
</script>

